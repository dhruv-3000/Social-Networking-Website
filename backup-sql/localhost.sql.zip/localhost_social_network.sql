-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 17, 2019 at 10:04 PM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social_network`
--
CREATE DATABASE IF NOT EXISTS `social_network` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `social_network`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(111) NOT NULL,
  `user_id` int(111) NOT NULL,
  `post_content` text NOT NULL,
  `upload_image` varchar(256) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `user_id`, `post_content`, `upload_image`, `post_date`) VALUES
(64, 13, 'dsdsdfdsfsd', 'apple-macbook-air-2017-22.jpg', '2019-03-07 11:34:27'),
(65, 13, 'Web Development', '', '2019-03-09 07:45:21'),
(67, 12, 'dsfdsf', '1200px-Node.js_logo.svg.png', '2019-03-07 18:47:49'),
(71, 12, 'dgdfgdfg', 'angular-JS-online-training-nareshit.jpg', '2019-03-07 18:53:05'),
(73, 12, 'hello wrold banlga\r\n', '', '2019-03-08 21:29:51'),
(80, 14, 'dsfdsfsd', 'construction.jpeg', '2019-03-07 19:55:25'),
(109, 15, 'No', 'aj-garcia-303540-768x512.jpg', '2019-03-08 13:07:27'),
(110, 15, 'bangladesh', '', '2019-03-08 13:18:05'),
(111, 15, 'No', 'BUFfWBGHRQDPJg42BwfKbJ-650-80.jpg', '2019-03-08 13:18:16'),
(112, 15, 'Hello B', 'construction.jpeg', '2019-03-08 13:20:41'),
(114, 14, 'fjsdlfsdf', 'BUFfWBGHRQDPJg42BwfKbJ-650-80.jpg', '2019-03-08 13:42:50'),
(115, 14, 'No', 'reactjs.jpg', '2019-03-08 13:43:14'),
(119, 12, 'dsfjdsjlfds', '', '2019-03-08 21:31:04'),
(120, 13, 'HI', '54456e93ecad04444d7efb7f-750-563.jpg', '2019-03-09 07:50:58'),
(121, 13, 'No', '34119118_2145124459065489_6457464594888654848_n.jpg', '2019-03-09 07:51:10'),
(122, 13, 'No', '12.jpg', '2019-03-09 07:51:27'),
(123, 13, 'No', 'angular-JS-online-training-nareshit.jpg', '2019-03-09 07:51:37'),
(124, 13, 'React js', 'reactjs.jpg', '2019-03-09 07:52:02'),
(125, 13, 'No', 'apple-macbook-pro-touch-bar-15-inch-2017-4193.jpg', '2019-03-09 07:52:19'),
(126, 13, 'No', 'apple-macbook-air-2017-21.jpg', '2019-03-09 07:52:28'),
(127, 13, 'No', 'main_photo_-_crystal_2048x2048.jpg', '2019-03-09 07:52:40'),
(128, 13, 'No', 'GlLRaZV.png', '2019-03-09 07:53:15'),
(129, 13, 'No', 'vue-spa-with-laravel.png', '2019-03-09 07:53:40'),
(130, 13, 'The theme for International Women&rsquo;s Day (8 March) this year, &ldquo;Think Equal, Build Smart, Innovate for Change&rdquo;, puts innovation by women and girls, for women and girls, at the heart of efforts to achieve gender equality.\r\n\r\nWe believe with equal rights, representation and empowerment women can be &lsquo;Agents of Change&rsquo; for Sustained Socio-economic Development around the world.\r\nWomensDay\r\nCUMUNA\r\n#ThinkGlobalGoGlobal', '', '2019-03-09 08:17:48'),
(135, 14, 'PHP jddd\r\n', '', '2019-03-09 13:02:58'),
(137, 17, 'Hi', '', '2019-03-09 11:28:06'),
(138, 17, 'No', '1_y6C4nSvy2Woe0m7bWEn4BA.png', '2019-03-09 11:28:25'),
(139, 14, 'Hello ', 'reactjs.jpg', '2019-03-09 12:54:12'),
(141, 20, 'bangla', '', '2019-03-09 13:24:54'),
(142, 21, 'sdfdsfdsf', 'brand-asus-company-logo-black-14.png', '2019-03-16 13:20:39'),
(144, 13, 'sdfjsdlfsdjklf', '', '2019-03-16 13:44:41'),
(145, 13, 'bd', '', '2019-03-16 13:44:01'),
(148, 14, 'java is a high level language.', 'apple-macbook-air-2017-21.jpg', '2019-03-28 05:28:29'),
(149, 14, 'i-Life ল্যাপটপ কিনে জিতে নিন স্বর্ণের চেইন !!\r\nস্টার টেক থেকে আমেরিকান ব্র্যান্ড i-Life এর ল্যাপটপ কিনে ক্র্যাচ কার্ড ঘষে জিতে নিতে পারেন স্বর্ণের চেইন, স্মার্ট ফোন, স্মার্ট ওয়াচ, নগদ ক্যাশ, ট্যাবলেট পিসি, হেডফোন, মাউস সহ আকর্ষণীয় সব নিশ্চিত উপহার!! অফারটি চলবে ২৬শে মার্চ ২০১৯ইং পর্যন্ত।\r\nমাত্র ১৬,৫০০ টাকায়, শিক্ষার্থী এবং অফিসের কাজের উপযোগী আমেরিকান ব্র্যান্ড আই লাইফের জেড এয়ার ল্যাপটপে রয়েছে-', '', '2019-03-28 06:51:16'),
(150, 14, '৪৮ বছর পেরিয়ে আজ ৪৯ তম স্বাধীনতা দিবস। স্বাধীন, সার্বভৌম এবং উন্নয়নশীল দেশ হিসেবে দুর্বার এগিয়ে যাচ্ছি বৈষম্যহীন, স্বাধীনতার আদর্শে উজ্জীবিত, স্বয়ংসম্পূর্ণ একটি রাষ্ট্র হিসেবে যার মূল চালিকা শক্তি মুক্তিযুদ্ধের আদর্শে উজ্জীবিত তরুণ সমাজ। তাদের নিয়ে ভবিষ্যৎ বাংলাদেশ বিনির্মাণের আশা ব্যক্ত করে সবাইকে জানাই স্বাধীনতা ও জাতীয় দিবসের শুভেচ্ছা।\r\n\r\n#স্বাধীনতাদিবস\r\n#চট্টগ্রাম_বিশ্ববিদ্যালয়_প্রতীকি_জাতিসংঘ_সংস্থা', '', '2019-03-28 06:53:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `f_name` text NOT NULL,
  `l_name` text NOT NULL,
  `user_name` text NOT NULL,
  `describe_user` varchar(255) NOT NULL,
  `Relationship` text NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_country` text NOT NULL,
  `user_gender` text NOT NULL,
  `user_birthday` text NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_cover` varchar(255) NOT NULL,
  `user_reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` text NOT NULL,
  `posts` text NOT NULL,
  `recovery_account` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `f_name`, `l_name`, `user_name`, `describe_user`, `Relationship`, `user_pass`, `user_email`, `user_country`, `user_gender`, `user_birthday`, `user_image`, `user_cover`, `user_reg_date`, `status`, `posts`, `recovery_account`) VALUES
(12, 'Apple ', 'Mac', 'apple _mac_422563', 'Hello.This is default status!', '...', 'A1234sdf', 'Apple@gmail.com', 'United States of America', 'Male', '1999-02-09', 'swift-og.png', '1534235562178595.jpg', '2019-03-05 09:53:19', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(13, 'mac', 'book', 'mac_book_497008', 'Hello.This is default status!', '...', 'A1234sdf', 'mac@gmail.com', 'India', 'Male', '2019-03-01', 'swift-og.png', 'RHBW5y1.png', '2019-03-07 10:39:09', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(14, 'nazmul', 'alom', 'nazmul_alom_859077', 'Hello.This is default status!', '...', 'A1234sdf', 'nazmul@gmail.com', 'Pakistan', 'Male', '2019-03-01', '36935858_940939389399875_5996963101969219584_n.jpg', 'vue-spa-with-laravel.png', '2019-03-07 19:16:52', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(15, 'ismail', 'tanbir', 'ismail_tanbir_997465', 'Hello.This is default status!', '...', 'A1234sdf', 'ismail@gmail.com', 'United States of America', 'Female', '2019-03-01', 'pic_angular.jpg', 'RHBW5y1.png.21', '2019-03-08 10:29:24', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(16, 'Kausar ', 'uddion', 'kausar _uddion_726113', 'Hello.This is default status!', '...', 'A1234sdf', 'kausar@gmail.com', 'Pakistan', 'Male', '2019-03-01', 'three.jpg', 'new.jpg', '2019-03-09 11:25:12', 'verified', 'no', 'Iwanttoputading intheuniverse.'),
(17, 'mamun', 'masud', 'mamun_masud_637084', 'Hello.This is default status!', '...', 'A1234sdf', 'mamun@gmail.com', 'Pakistan', 'Male', '2015-02-03', 'four.png', 'new.jpg', '2019-03-09 11:25:49', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(18, 'Hasan ', 'Tareq', 'hasan _tareq_638001', 'Hello.This is default status!', '...', 'A1234sdf', 'hasan@gmail.com', 'Pakistan', 'Male', '2019-03-06', 'three.jpg', 'new.jpg', '2019-03-09 11:26:17', 'verified', 'no', 'Iwanttoputading intheuniverse.'),
(19, 'Md', 'Rayhan', 'md_rayhan_158991', 'Hello.This is default status!', '...', 'A1234sdf', 'rayhan@gmail.com', 'United States of America', 'Male', '2019-03-01', 'four.png', 'new.jpg', '2019-03-09 11:26:51', 'verified', 'no', 'Iwanttoputading intheuniverse.'),
(20, 'tanjina', 'akter', 'tanjina_akter_323558', 'Hello.This is default status!', '...', 'A1234sdf', 'tanjina@gmail.com', 'United States of America', 'Female', '1999-02-23', 'swift-app-development-services.png', '34119118_2145124459065489_6457464594888654848_n.jpg', '2019-03-09 13:14:02', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(21, 'jahed', 'uddin', 'jahed_uddin_149057', 'Hello.This is default status!', '...', 'A1234sdf', 'jahed@gmail.com', 'UK', 'Male', '2019-03-01', 'Screen Shot 2019-03-05 at 1.56.42 am.png', 'GlLRaZV.png', '2019-03-16 13:18:37', 'verified', 'yes', 'Iwanttoputading intheuniverse.'),
(22, 'dsfdsfs', 'sdfdsf', 'dsfdsfs_sdfdsf_615568', 'Hello.This is default status!', '...', 'A1234sdf', 'Apple@gmail.com', 'United States of America', 'Male', '2019-03-05', 'four.png', 'new.jpg', '2019-03-16 13:30:18', 'verified', 'no', 'Iwanttoputading intheuniverse.'),
(23, 'nazmul', 'akram', 'nazmul_akram_224344', 'Hello.This is default status!', '...', 'A1234sdf', 'nazmulalom@gmail.com', 'Pakistan', 'Male', '2019-07-02', 'three.jpg', 'new.jpg', '2019-07-17 20:08:49', 'verified', 'no', 'Iwanttoputading intheuniverse.');

-- --------------------------------------------------------

--
-- Table structure for table `user_messages`
--

CREATE TABLE `user_messages` (
  `id` int(11) NOT NULL,
  `user_to` int(11) NOT NULL,
  `user_from` int(11) NOT NULL,
  `msg_body` varchar(2500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `msg_seen` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_messages`
--

INSERT INTO `user_messages` (`id`, `user_to`, `user_from`, `msg_body`, `date`, `msg_seen`) VALUES
(17, 12, 14, 'hi', '2019-03-15 06:24:39', 'no'),
(18, 12, 14, 'hi', '2019-03-15 06:24:45', 'no'),
(19, 13, 14, 'gfdgdfgdf', '2019-03-15 06:25:55', 'no'),
(20, 13, 14, 'gfdgdfgdf', '2019-03-15 06:25:59', 'no'),
(21, 14, 12, 'hello', '2019-03-15 06:49:44', 'no'),
(22, 14, 12, 'hello', '2019-03-15 06:49:48', 'no'),
(23, 14, 12, 'hello', '2019-03-15 08:00:24', 'no'),
(24, 14, 12, 'kemon acen?', '2019-03-15 08:00:46', 'no'),
(25, 14, 12, 'kemon acen?', '2019-03-15 08:00:50', 'no'),
(26, 12, 14, 'alhamdulillah valo', '2019-03-15 08:01:27', 'no'),
(27, 12, 14, 'valo achi', '2019-03-15 08:01:41', 'no'),
(28, 12, 14, 'valo achi', '2019-03-15 08:01:44', 'no'),
(29, 12, 14, 'hi', '2019-03-15 08:02:34', 'no'),
(30, 14, 12, 'hello', '2019-03-15 08:02:45', 'no'),
(31, 14, 12, 'ki obsta', '2019-03-15 08:17:10', 'no'),
(32, 12, 14, 'valo', '2019-03-15 08:17:47', 'no'),
(33, 12, 14, 'hello', '2019-03-15 08:22:09', 'no'),
(34, 14, 12, 'ki kbr?', '2019-03-15 08:22:31', 'no'),
(35, 12, 14, 'aj ct ase software lab ar', '2019-03-15 08:22:53', 'no'),
(36, 14, 12, 'thank you for inform me bondu', '2019-03-15 08:23:35', 'no'),
(37, 13, 14, 'hello ', '2019-03-15 08:30:06', 'no'),
(38, 14, 13, 'HI', '2019-03-16 12:49:29', 'no'),
(39, 13, 14, 'how are you?', '2019-03-16 12:50:14', 'no'),
(40, 14, 13, 'i am fine. u?', '2019-03-16 12:50:33', 'no'),
(41, 13, 14, 'hi', '2019-03-16 12:59:39', 'no'),
(42, 14, 13, 'hello', '2019-03-16 13:00:20', 'no'),
(43, 14, 13, 'hello', '2019-03-16 13:01:39', 'no'),
(44, 15, 14, 'hi', '2019-03-16 13:04:40', 'no'),
(45, 13, 14, 'hi jahed', '2019-03-16 13:05:36', 'no'),
(46, 14, 13, 'ki kbr ? tour a jabi?\r\n', '2019-03-16 13:05:52', 'no'),
(47, 13, 14, 'hmm . sokal 6tai cole asis.ok?', '2019-03-16 13:06:15', 'no'),
(48, 14, 13, 'ok bondu thank you.', '2019-03-16 13:06:31', 'no'),
(49, 14, 21, 'hiii', '2019-03-16 13:21:10', 'no'),
(50, 21, 14, 'hello', '2019-03-16 13:21:48', 'no'),
(51, 14, 23, 'hi', '2019-07-17 20:10:05', 'no');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_messages`
--
ALTER TABLE `user_messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `com_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `user_messages`
--
ALTER TABLE `user_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
